// myconfig.js
export const projectName = ``;

export const projectBase = projectName ? `/${projectName}` : '';
export const projectBaseWithSlash = projectBase ? `${projectBase}/` : '/';
